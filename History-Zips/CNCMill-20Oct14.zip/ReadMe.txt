Product: CNC Mill laser cut parts, October 2014

Designer: Warrick Smith

Support:  http://forums.obrary.com/category/designs/cnc-mill

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democritized product design

Description:
This is for the laser cut parts needed for the CNC Mill on Instructables.  We'll print the pieces out for and ship it so you can assemble your very own CNC Mill.  You'll still need to 3D print many parts and buy the other components listed on Instructables.
